<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MyBuyerWallet extends Model{
    use HasFactory;
    protected $table = 'my_buyer_wallets';
}
