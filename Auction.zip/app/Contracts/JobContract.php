<?php

namespace App\Contracts;

/**
 * Interface JobContract
 * @package App\Contracts
 */
interface JobContract{
    
    public function getAllJobs();

}
