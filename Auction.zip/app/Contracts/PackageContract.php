<?php

namespace App\Contracts;

interface PackageContract{

    //  package
     public function getAllPackages();
     public function CreatePackage(array $data);
     public function StatusPackage($id);
     public function GetPackageById($id);
     public function DeletePackage($id);
     public function updatePackage(array $data);
}