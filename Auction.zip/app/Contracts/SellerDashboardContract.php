<?php

namespace App\Contracts;

interface SellerDashboardContract{
} 
?>