@extends('front.layout.app')
@section('section')

<!-- content  -->
 terms % condition

@endsection
@section('script')