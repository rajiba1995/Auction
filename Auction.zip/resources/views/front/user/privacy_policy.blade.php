@extends('front.layout.app')
@section('section')

<!-- content  -->
 privacy policy

@endsection
@section('script')